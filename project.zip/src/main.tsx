import React from "react";
import { createRoot } from "react-dom/client";
import { LocalNotifications } from "@capacitor/local-notifications";
import { registerPlugin } from "@capacitor/core";

interface NextPrayerWidgetPlugin {
  updateWidget(options: { name: string; time: string }): Promise<void>;
}
const NextPrayerWidget = registerPlugin<NextPrayerWidgetPlugin>("NextPrayerWidget");

// Native plugin: schedules a real AlarmManager alarm per prayer time that opens
// a full-screen "adhan" activity (mosque visual) even if the phone is locked or
// another app (WhatsApp/Facebook/etc.) is open in the foreground.
interface AdhanItem {
  id: number;
  at: number; // epoch millis
  prayerName: string;
  isFajr: boolean;
  // "adhan" (الأذان + الدعاء) | "pre10" (تنبيه صوتي قبل الصلاة بـ10 دقايق) | "pre5" (قبلها بـ5)
  kind?: "adhan" | "pre10" | "pre5";
}
interface AdhanFullScreenPlugin {
  schedule(options: { items: AdhanItem[] }): Promise<void>;
  cancel(options: { ids: number[] }): Promise<void>;
  cancelRange(options: { min: number; max: number }): Promise<void>;
  requestIgnoreBatteryOptimizations(): Promise<{ alreadyIgnoring: boolean }>;
}
const AdhanFullScreen = registerPlugin<AdhanFullScreenPlugin>("AdhanFullScreen");

// The visual UI is kept in index.html for compatibility with simple APK builders.
// This file provides the native Android notification bridge used by the UI.

const STOP_ADHAN_ACTION_TYPE = "STOP_ADHAN_ACTIONS";

async function registerAdhanActions() {
  try {
    await LocalNotifications.registerActionTypes({
      types: [
        {
          id: STOP_ADHAN_ACTION_TYPE,
          actions: [{ id: "stop-adhan", title: "⏹️ إيقاف الأذان" }],
        },
      ],
    });
  } catch (e) {
    // Action registration can silently fail on very old Android versions.
  }
}

async function handleAdhanAction(event: any) {
  try {
    if (event?.actionId === "stop-adhan" && event?.notification?.id) {
      await LocalNotifications.cancel({ notifications: [{ id: event.notification.id }] });
    }
  } catch (_) {}
}
LocalNotifications.addListener("localNotificationActionPerformed", handleAdhanAction);

async function requestNotificationPermission() {
  try {
    const current = await LocalNotifications.checkPermissions();
    if (current.display !== "granted") {
      const requested = await LocalNotifications.requestPermissions();
      return requested.display === "granted";
    }
    return true;
  } catch (e) {
    return false;
  }
}

async function ensureAdhanChannel() {
  try {
    // NOTE: Android locks a notification channel's sound/settings permanently once created
    // with a given id — it cannot be changed later even by re-calling createChannel with the
    // same id, so we bump the id whenever the behaviour changes.
    // v4: القناة بقت "صامتة" عمدًا (بدون sound) — صوت الأذان الحقيقي بقى يتشغّل يدويًا
    // جوه AdhanScreenActivity على مجرى المنبّه (STREAM_ALARM) بدل مجرى الإشعارات العادي،
    // عشان صوت الأذان ما يتقطعش أو يتخفّتش لو جه إشعار من تطبيق تاني في نفس اللحظة.
    await LocalNotifications.createChannel({
      id: "adhan-channel-v4",
      name: "مواقيت الصلاة (أذان)",
      description: "تنبيه بدخول وقت كل صلاة (عدا الفجر) — الصوت يعمل على مجرى المنبّه",
      importance: 5,
      visibility: 1,
    });
  } catch (e) {
    // Channel creation can fail on older Android versions; the full-screen alarm still works.
  }
}

async function ensureAdhanFajrChannel() {
  try {
    await LocalNotifications.createChannel({
      id: "adhan-fajr-channel-v3",
      name: "أذان الفجر",
      description: "تنبيه بدخول وقت صلاة الفجر — الصوت يعمل على مجرى المنبّه",
      importance: 5,
      visibility: 1,
    });
  } catch (e) {
    // Channel creation can fail on older Android versions; the full-screen alarm still works.
  }
}

async function ensureDhikrChannel() {
  try {
    await LocalNotifications.createChannel({
      id: "dhikr-channel-v2",
      name: "تذكير دوري بالأذكار",
      description: "تنبيه صوتي بذكر بسيط بشكل دوري",
      importance: 5,
      sound: "dhikr1.mp3",
      visibility: 1,
    });
  } catch (e) {
    // Channel creation can fail on older Android versions; notifications still work without it.
  }
}

async function ensurePrayerReminderChannel() {
  try {
    await LocalNotifications.createChannel({
      id: "prayer-reminder-channel-v1",
      name: "تنبيه قبل الصلاة بـ10 دقائق",
      description: "تنبيه خفيف بصوت الإشعار الافتراضي قبل دخول وقت الصلاة بعشر دقائق",
      importance: 4,
      visibility: 1,
    });
  } catch (e) {
    // Channel creation can fail on older Android versions; notifications still work without a custom sound.
  }
}

async function ensureAllChannels() {
  await ensureAdhanChannel();
  await ensureAdhanFajrChannel();
  await ensureDhikrChannel();
  await ensurePrayerReminderChannel();
}

async function scheduleNotifications(notifications: any[]) {
  try {
    const ok = await requestNotificationPermission();
    if (!ok) return false;
    await ensureAllChannels();
    await registerAdhanActions();
    await LocalNotifications.schedule({ notifications });
    return true;
  } catch (e) {
    return false;
  }
}

async function scheduleAdhanAlarms(items: AdhanItem[]) {
  try {
    const ok = await requestNotificationPermission();
    if (!ok) return false;
    // Uses the same channel ids as the regular adhan notifications, so the
    // correct adhan/adhan_fajr sound plays exactly as before — this only adds
    // the full-screen mosque activity on top of it.
    await ensureAllChannels();
    await AdhanFullScreen.schedule({ items });
    return true;
  } catch (e) {
    return false;
  }
}

async function cancelAdhanAlarms(ids: number[]) {
  try {
    if (ids.length) await AdhanFullScreen.cancel({ ids });
  } catch (_) {}
}

// يمسح كل تنبيهات الأذان/التنبيه المسبق المجدولة (نطاق الـ ids) قبل إعادة الجدولة الكاملة
async function cancelAdhanRange(min: number, max: number) {
  try {
    await AdhanFullScreen.cancelRange({ min, max });
  } catch (_) {}
}

// يطلب استثناء التطبيق من توفير البطارية عشان الأذان يشتغل والتطبيق مقفول
async function requestIgnoreBattery() {
  try {
    await AdhanFullScreen.requestIgnoreBatteryOptimizations();
  } catch (_) {}
}

async function cancelNotifications(ids: number[]) {
  try {
    let target = ids;
    if (!target.length) {
      const pending = await LocalNotifications.getPending();
      target = pending.notifications
        .map((n: any) => n.id)
        .filter((id: number) => (id >= 1200 && id < 1400) || (id >= 5000 && id < 5300) || (id >= 8000 && id < 8300));
    }
    if (target.length) {
      await LocalNotifications.cancel({ notifications: target.map(id => ({ id })) });
    }
  } catch (_) {}
}

(window as any).ZekrniNativeNotifications = {
  requestNotificationPermission,
  scheduleNotifications,
  cancelNotifications,
  scheduleAdhanAlarms,
  cancelAdhanAlarms,
  cancelAdhanRange,
  requestIgnoreBattery,
  plugin: LocalNotifications,
};

(window as any).ZekrniWidget = {
  updateWidget: (name: string, time: string) =>
    NextPrayerWidget.updateWidget({ name, time }).catch(() => {}),
};

function App() { return null; }

const root = document.getElementById("react-root");
if (root) createRoot(root).render(<App />);
