import React from "react";
import { createRoot } from "react-dom/client";
import { LocalNotifications } from "@capacitor/local-notifications";
import { registerPlugin } from "@capacitor/core";

interface NextPrayerWidgetPlugin {
  updateWidget(options: { name: string; time: string }): Promise<void>;
}
const NextPrayerWidget = registerPlugin<NextPrayerWidgetPlugin>("NextPrayerWidget");

// The visual UI is kept in index.html for compatibility with simple APK builders.
// This file provides the native Android notification bridge used by the UI.

const STOP_ADHAN_ACTION_TYPE = "STOP_ADHAN_ACTIONS";

async function registerAdhanActions() {
  try {
    await LocalNotifications.registerActionTypes({
      types: [
        {
          id: STOP_ADHAN_ACTION_TYPE,
          actions: [{ id: "stop-adhan", title: "⏹️ إيقاف الأذان" }],
        },
      ],
    });
  } catch (e) {
    // Action registration can silently fail on very old Android versions.
  }
}

async function handleAdhanAction(event: any) {
  try {
    if (event?.actionId === "stop-adhan" && event?.notification?.id) {
      await LocalNotifications.cancel({ notifications: [{ id: event.notification.id }] });
    }
  } catch (_) {}
}
LocalNotifications.addListener("localNotificationActionPerformed", handleAdhanAction);

async function requestNotificationPermission() {
  try {
    const current = await LocalNotifications.checkPermissions();
    if (current.display !== "granted") {
      const requested = await LocalNotifications.requestPermissions();
      return requested.display === "granted";
    }
    return true;
  } catch (e) {
    return false;
  }
}

async function ensureAdhanChannel() {
  try {
    // NOTE: Android locks a notification channel's sound/settings permanently once created
    // with a given id — it cannot be changed later even by re-calling createChannel with the
    // same id. If the app was ever installed before with the old "adhan-channel" id (silent
    // or wrong sound), we must use a NEW id so Android creates a fresh channel with the
    // correct sound. Bump this id again in the future if the sound ever needs to change.
    await LocalNotifications.createChannel({
      id: "adhan-channel-v3",
      name: "مواقيت الصلاة (أذان)",
      description: "تنبيه صوتي بالأذان عند دخول وقت كل صلاة (عدا الفجر)",
      importance: 5,
      sound: "adhan.mp3",
      visibility: 1,
    });
  } catch (e) {
    // Channel creation can fail on older Android versions; notifications still work without a custom sound.
  }
}

async function ensureAdhanFajrChannel() {
  try {
    await LocalNotifications.createChannel({
      id: "adhan-fajr-channel-v2",
      name: "أذان الفجر",
      description: "تنبيه صوتي خاص بأذان صلاة الفجر",
      importance: 5,
      sound: "adhan_fajr.mp3",
      visibility: 1,
    });
  } catch (e) {
    // Channel creation can fail on older Android versions; notifications still work without a custom sound.
  }
}

async function ensureDhikrChannel() {
  try {
    await LocalNotifications.createChannel({
      id: "dhikr-channel-v2",
      name: "تذكير دوري بالأذكار",
      description: "تنبيه صوتي بذكر بسيط بشكل دوري",
      importance: 5,
      sound: "dhikr1.mp3",
      visibility: 1,
    });
  } catch (e) {
    // Channel creation can fail on older Android versions; notifications still work without it.
  }
}

async function ensurePrayerReminderChannel() {
  try {
    await LocalNotifications.createChannel({
      id: "prayer-reminder-channel-v1",
      name: "تنبيه قبل الصلاة بـ10 دقائق",
      description: "تنبيه خفيف بصوت الإشعار الافتراضي قبل دخول وقت الصلاة بعشر دقائق",
      importance: 4,
      visibility: 1,
    });
  } catch (e) {
    // Channel creation can fail on older Android versions; notifications still work without a custom sound.
  }
}

async function scheduleNotifications(notifications: any[]) {
  try {
    const ok = await requestNotificationPermission();
    if (!ok) return false;
    await ensureAdhanChannel();
    await ensureAdhanFajrChannel();
    await ensureDhikrChannel();
    await ensurePrayerReminderChannel();
    await registerAdhanActions();
    await LocalNotifications.schedule({ notifications });
    return true;
  } catch (e) {
    return false;
  }
}

async function cancelNotifications(ids: number[]) {
  try {
    let target = ids;
    if (!target.length) {
      const pending = await LocalNotifications.getPending();
      target = pending.notifications
        .map((n: any) => n.id)
        .filter((id: number) => (id >= 1200 && id < 1400) || (id >= 5000 && id < 5300));
    }
    if (target.length) {
      await LocalNotifications.cancel({ notifications: target.map(id => ({ id })) });
    }
  } catch (_) {}
}

(window as any).ZekrniNativeNotifications = {
  requestNotificationPermission,
  scheduleNotifications,
  cancelNotifications,
  plugin: LocalNotifications,
};

(window as any).ZekrniWidget = {
  updateWidget: (name: string, time: string) =>
    NextPrayerWidget.updateWidget({ name, time }).catch(() => {}),
};

function App() { return null; }

const root = document.getElementById("react-root");
if (root) createRoot(root).render(<App />);
