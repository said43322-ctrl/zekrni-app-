package com.zekrni.android;

import android.content.Context;
import android.content.SharedPreferences;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Bridge that lets the web UI (index.html) push the next-prayer name/time
 * into SharedPreferences so the home-screen widget (NextPrayerWidgetProvider)
 * can display it, then asks Android to redraw every placed widget instance.
 */
@CapacitorPlugin(name = "NextPrayerWidget")
public class NextPrayerWidgetPlugin extends Plugin {

    @PluginMethod
    public void updateWidget(PluginCall call) {
        String name = call.getString("name", "—");
        String time = call.getString("time", "—");

        Context context = getContext();
        SharedPreferences prefs = context.getSharedPreferences(
                NextPrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit()
                .putString(NextPrayerWidgetProvider.KEY_NAME, name)
                .putString(NextPrayerWidgetProvider.KEY_TIME, time)
                .apply();

        NextPrayerWidgetProvider.updateAllWidgets(context);

        call.resolve(new JSObject());
    }
}
