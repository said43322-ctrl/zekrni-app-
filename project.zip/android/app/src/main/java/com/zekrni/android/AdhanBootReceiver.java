package com.zekrni.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** يعيد تسجيل المنبّه التالي بعد إعادة تشغيل الجهاز أو تحديث التطبيق أو تغيير الوقت/المنطقة الزمنية. */
public class AdhanBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        long now = System.currentTimeMillis();
        AdhanStore.pruneStale(context, now - AdhanScheduler.STALE_MS);
        AdhanScheduler.scheduleNext(context);
    }
}
