package com.zekrni.android;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

/**
 * Home-screen widget that shows the next prayer name + time.
 * The actual data (name/time) is written into SharedPreferences by
 * NextPrayerWidgetPlugin whenever the app (WebView) recomputes the
 * next prayer, then this provider re-renders every widget instance.
 */
public class NextPrayerWidgetProvider extends AppWidgetProvider {

    public static final String PREFS_NAME = "ZekrniWidgetPrefs";
    public static final String KEY_NAME = "next_prayer_name";
    public static final String KEY_TIME = "next_prayer_time";

    public static void updateAllWidgets(Context context) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(context);
        int[] ids = mgr.getAppWidgetIds(new android.content.ComponentName(context, NextPrayerWidgetProvider.class));
        if (ids.length > 0) {
            new NextPrayerWidgetProvider().onUpdate(context, mgr, ids);
        }
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String name = prefs.getString(KEY_NAME, "—");
        String time = prefs.getString(KEY_TIME, "—");

        for (int appWidgetId : appWidgetIds) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.next_prayer_widget);
            views.setTextViewText(R.id.widget_prayer_name, name);
            views.setTextViewText(R.id.widget_prayer_time, time);
            appWidgetManager.updateAppWidget(appWidgetId, views);
        }
    }
}
