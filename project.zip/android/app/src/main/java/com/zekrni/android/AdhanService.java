package com.zekrni.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * خدمة أمامية (Foreground Service) بتشغّل الصوت على مجرى المنبّه (STREAM_ALARM):
 *  - الأذان: مرة واحدة فقط (من غير تكرار) ← وبعده دعاء "اللهم رب هذه الدعوة التامة" ← وبعدها تقفل لوحدها
 *  - قبل الصلاة بـ10 دقايق: ملف prayer_alert
 *  - قبل الصلاة بـ5 دقايق: ملف prayer_alert_5
 * ملفات الصوت بتتدوّر عليها بالاسم في res/raw، ولو ملف مش موجود بيتخطّاه من غير ما التطبيق يقع.
 */
public class AdhanService extends Service {
    static final String ACTION_PLAY = "com.zekrni.android.ADHAN_PLAY";
    static final String ACTION_STOP = "com.zekrni.android.ADHAN_STOP";
    /** بيتبعت لما الأذان (والدعاء) يخلصوا، عشان شاشة الأذان تقفل لوحدها. */
    static final String ACTION_DONE = "com.zekrni.android.ADHAN_DONE";

    static final String KIND_ADHAN = "adhan";
    static final String KIND_PRE10 = "pre10";
    static final String KIND_PRE5 = "pre5";

    private static final String CH_PLAY = "adhan-service-v1";
    private static final String CH_INFO = "prayer-info-v1";
    private static final int NOTIF_ID = 4242;
    private static final int INFO_NOTIF_ID = 4243;

    private MediaPlayer player;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private final AudioManager.OnAudioFocusChangeListener focusListener = change -> { };
    private List<Integer> queue = new ArrayList<>();
    private int index = 0;
    private String kind = KIND_ADHAN;
    private String prayerName = "";

    // ---------- بناء الـ Intent من عنصر الجدول (بيرجّع null لو ملف الصوت غير موجود) ----------
    static Intent buildPlayIntent(Context ctx, JSONObject item) {
        String kind = item.optString("kind", KIND_ADHAN);
        boolean isFajr = item.optBoolean("isFajr", false);
        if (soundQueue(ctx, kind, isFajr).isEmpty()) return null;
        Intent i = new Intent(ctx, AdhanService.class);
        i.setAction(ACTION_PLAY);
        i.putExtra("kind", kind);
        i.putExtra("prayerName", item.optString("prayerName", ""));
        i.putExtra("isFajr", isFajr);
        i.putExtra("id", item.optInt("id", 0));
        return i;
    }

    private static int rawId(Context ctx, String name) {
        return ctx.getResources().getIdentifier(name, "raw", ctx.getPackageName());
    }

    private static List<Integer> soundQueue(Context ctx, String kind, boolean isFajr) {
        List<Integer> q = new ArrayList<>();
        if (KIND_PRE10.equals(kind)) {
            int r = rawId(ctx, "prayer_alert");
            if (r != 0) q.add(r);
        } else if (KIND_PRE5.equals(kind)) {
            int r = rawId(ctx, "prayer_alert_5");
            if (r != 0) q.add(r);
        } else {
            int adhan = rawId(ctx, isFajr ? "adhan_fajr" : "adhan");
            if (adhan != 0) {
                q.add(adhan);
                int dua = rawId(ctx, "adhan_dua");
                if (dua != 0) q.add(dua);
            }
        }
        return q;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_STOP.equals(intent.getAction())) {
            stopEverything(false);
            return START_NOT_STICKY;
        }

        kind = intent.getStringExtra("kind");
        if (kind == null) kind = KIND_ADHAN;
        prayerName = intent.getStringExtra("prayerName");
        if (prayerName == null) prayerName = "";
        boolean isFajr = intent.getBooleanExtra("isFajr", false);

        // لازم startForeground يتنادى بسرعة بعد startForegroundService
        Notification n = buildOngoingNotification();
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) {
            // لو النظام رفض الخدمة الأمامية، نكمل تشغيل الصوت برضه قدر الإمكان
        }

        if (KIND_ADHAN.equals(kind)) launchAdhanScreen();

        releasePlayer();
        queue = soundQueue(this, kind, isFajr);
        index = 0;
        requestFocus();
        playNext();
        return START_NOT_STICKY;
    }

    // ---------- تشغيل الصوت بالتسلسل ----------
    private AudioAttributes alarmAttrs() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
    }

    private void requestFocus() {
        try {
            audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (audioManager == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                        .setAudioAttributes(alarmAttrs())
                        .setOnAudioFocusChangeListener(focusListener)
                        .build();
                audioManager.requestAudioFocus(focusRequest);
            } else {
                audioManager.requestAudioFocus(focusListener, AudioManager.STREAM_ALARM,
                        AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE);
            }
        } catch (Exception ignored) {
            // نشغّل الصوت حتى لو رفض النظام الأولوية
        }
    }

    private void abandonFocus() {
        try {
            if (audioManager == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && focusRequest != null) {
                audioManager.abandonAudioFocusRequest(focusRequest);
            } else {
                audioManager.abandonAudioFocus(focusListener);
            }
        } catch (Exception ignored) {
        }
    }

    private void playNext() {
        releasePlayer();
        if (index >= queue.size()) {
            stopEverything(true);
            return;
        }
        int res = queue.get(index++);
        try {
            MediaPlayer mp = new MediaPlayer();
            player = mp;
            mp.setAudioAttributes(alarmAttrs());
            mp.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
            AssetFileDescriptor afd = getResources().openRawResourceFd(res);
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mp.setLooping(false); // الأذان مرة واحدة بس
            mp.setOnCompletionListener(p -> playNext());
            mp.setOnErrorListener((p, what, extra) -> {
                playNext();
                return true;
            });
            mp.prepare();
            mp.start();
        } catch (Exception e) {
            playNext(); // ملف تالف؟ نعدّي للي بعده
        }
    }

    private void releasePlayer() {
        try {
            if (player != null) {
                player.setOnCompletionListener(null);
                player.setOnErrorListener(null);
                if (player.isPlaying()) player.stop();
                player.release();
            }
        } catch (Exception ignored) {
        }
        player = null;
    }

    /** completed=true يعني خلص طبيعي (مش المستخدمة اللي وقّفته). */
    private void stopEverything(boolean completed) {
        releasePlayer();
        abandonFocus();
        boolean wasAdhan = KIND_ADHAN.equals(kind);
        if (wasAdhan) {
            sendBroadcast(new Intent(ACTION_DONE).setPackage(getPackageName()));
        }
        stopForeground(true);
        if (completed && !wasAdhan) postInfoNotification();
        stopSelf();
    }

    @Override
    public void onDestroy() {
        releasePlayer();
        abandonFocus();
        super.onDestroy();
    }

    // ---------- الإشعارات ----------
    private void ensureChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel play = new NotificationChannel(CH_PLAY, "تشغيل الأذان والتنبيهات",
                NotificationManager.IMPORTANCE_HIGH);
        play.setDescription("إشعار أثناء تشغيل الأذان أو التنبيه الصوتي قبل الصلاة");
        play.setSound(null, null);
        play.enableVibration(false);
        play.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(play);
        NotificationChannel info = new NotificationChannel(CH_INFO, "تنبيهات قبل الصلاة",
                NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(info);
    }

    private int pendingFlags() {
        int f = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) f |= PendingIntent.FLAG_IMMUTABLE;
        return f;
    }

    private String preText() {
        int mins = KIND_PRE5.equals(kind) ? 5 : 10;
        return "باقي " + mins + " دقائق على أذان " + prayerName;
    }

    private Notification buildOngoingNotification() {
        ensureChannels();
        Intent stop = new Intent(this, AdhanService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, pendingFlags());

        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CH_PLAY)
                .setSmallIcon(getApplicationInfo().icon)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setOngoing(true)
                .addAction(0, "⏹ إيقاف", stopPi);

        if (KIND_ADHAN.equals(kind)) {
            b.setContentTitle("🕌 ذَكِّرني — أذان " + prayerName)
                    .setContentText("حان الآن وقت صلاة " + prayerName)
                    .setCategory(NotificationCompat.CATEGORY_ALARM)
                    .setFullScreenIntent(adhanScreenPendingIntent(), true)
                    .setContentIntent(adhanScreenPendingIntent());
        } else {
            PendingIntent open = PendingIntent.getActivity(this, 2,
                    new Intent(this, MainActivity.class), pendingFlags());
            b.setContentTitle("⏳ ذَكِّرني — تنبيه")
                    .setContentText(preText())
                    .setCategory(NotificationCompat.CATEGORY_REMINDER)
                    .setContentIntent(open);
        }
        return b.build();
    }

    private void postInfoNotification() {
        try {
            PendingIntent open = PendingIntent.getActivity(this, 2,
                    new Intent(this, MainActivity.class), pendingFlags());
            Notification n = new NotificationCompat.Builder(this, CH_INFO)
                    .setSmallIcon(getApplicationInfo().icon)
                    .setContentTitle("⏳ ذَكِّرني — تنبيه")
                    .setContentText(preText())
                    .setAutoCancel(true)
                    .setContentIntent(open)
                    .build();
            NotificationManagerCompat.from(this).notify(INFO_NOTIF_ID, n);
        } catch (SecurityException ignored) {
            // إذن الإشعارات غير ممنوح
        }
    }

    private Intent adhanScreenIntent() {
        Intent i = new Intent(this, AdhanScreenActivity.class);
        i.putExtra("prayerName", prayerName);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        return i;
    }

    private PendingIntent adhanScreenPendingIntent() {
        return PendingIntent.getActivity(this, 3, adhanScreenIntent(), pendingFlags());
    }

    /** بعض الأجهزة بتتجاهل الـ full-screen intent والشاشة شغالة، فنحاول نفتح الشاشة مباشرة كمان. */
    private void launchAdhanScreen() {
        try {
            startActivity(adhanScreenIntent());
        } catch (Exception ignored) {
        }
    }
}
