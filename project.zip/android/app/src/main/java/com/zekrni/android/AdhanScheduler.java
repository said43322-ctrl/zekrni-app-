package com.zekrni.android;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONObject;

import java.util.List;

/** يسجّل في AlarmManager منبّه واحد فقط: أقرب تنبيه قادم من المخزن. */
final class AdhanScheduler {
    static final String ACTION_TICK = "com.zekrni.android.ADHAN_TICK";
    private static final int TICK_REQUEST_CODE = 7001;
    /** أي تنبيه فات وقته بأكتر من دقيقتين ما بيتشغّلش متأخر. */
    static final long STALE_MS = 2 * 60 * 1000L;

    private AdhanScheduler() {}

    private static int immutableFlag() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0;
    }

    private static PendingIntent tickIntent(Context ctx) {
        Intent i = new Intent(ctx, AdhanAlarmReceiver.class);
        i.setAction(ACTION_TICK);
        return PendingIntent.getBroadcast(ctx, TICK_REQUEST_CODE, i,
                PendingIntent.FLAG_UPDATE_CURRENT | immutableFlag());
    }

    static void scheduleNext(Context ctx) {
        Context app = ctx.getApplicationContext();
        AlarmManager am = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        long now = System.currentTimeMillis();
        long next = Long.MAX_VALUE;
        List<JSONObject> items = AdhanStore.load(app);
        for (JSONObject o : items) {
            long at = o.optLong("at", 0);
            if (at > now - STALE_MS && at < next) next = at;
        }

        PendingIntent pi = tickIntent(app);
        if (next == Long.MAX_VALUE) {
            am.cancel(pi);
            return;
        }
        if (next < now + 1000) next = now + 1000;

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                setAlarmClock(app, am, next, pi);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, next, pi);
            }
        } catch (SecurityException e) {
            setAlarmClock(app, am, next, pi);
        }
    }

    private static void setAlarmClock(Context app, AlarmManager am, long at, PendingIntent pi) {
        PendingIntent show = PendingIntent.getActivity(app, 0,
                new Intent(app, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | immutableFlag());
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), pi);
    }
}
