package com.zekrni.android;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class AdhanAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int id = intent.getIntExtra("id", (int) System.currentTimeMillis());
        String prayerName = intent.getStringExtra("prayerName");
        if (prayerName == null) prayerName = "";
        boolean isFajr = intent.getBooleanExtra("isFajr", false);

        // القنوات دي أصبحت "صامتة" (مفيش sound في تعريفها) — الصوت الحقيقي بقى
        // بيتشغّل يدويًا جوه AdhanScreenActivity على مجرى المنبّه (STREAM_ALARM)
        // عشان محدش يقدر يقاطعه أو يخفّته بإشعار من تطبيق تاني.
        String channelId = isFajr ? "adhan-fajr-channel-v3" : "adhan-channel-v4";

        Intent fullScreenIntent = new Intent(context, AdhanScreenActivity.class);
        fullScreenIntent.putExtra("prayerName", prayerName);
        fullScreenIntent.putExtra("notificationId", id);
        fullScreenIntent.putExtra("isFajr", isFajr);
        fullScreenIntent.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_NO_USER_ACTION
        );

        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            piFlags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent fullScreenPendingIntent = PendingIntent.getActivity(
            context, id, fullScreenIntent, piFlags
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
            .setSmallIcon(context.getApplicationInfo().icon)
            .setContentTitle("🕌 ذَكِّرني — " + prayerName)
            .setContentText("حان الآن وقت صلاة " + prayerName)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent)
            .setAutoCancel(true);

        NotificationManagerCompat.from(context).notify(id, builder.build());

        // Some OEMs (Xiaomi/MIUI, Oppo/ColorOS, etc.) suppress the notification's
        // fullScreenIntent while the screen is already on, so also try launching
        // the activity directly as a fallback — this succeeds in most cases when
        // triggered from an alarm broadcast (alarm-clock–style background start).
        try {
            context.startActivity(fullScreenIntent);
        } catch (Exception e) {
            // If the OEM blocks background activity starts, the full-screen
            // notification above remains the reliable path.
        }
    }
}
