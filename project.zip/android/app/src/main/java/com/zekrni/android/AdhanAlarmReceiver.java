package com.zekrni.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.util.List;

/**
 * بيصحى وقت أي تنبيه (أذان / قبل الصلاة بـ10 / قبل الصلاة بـ5)، يبدأ خدمة الصوت،
 * وبعدين يسجّل المنبّه اللي بعده. شغال حتى لو التطبيق مقفول أو الموقع مقفول،
 * لأن الجدول كله متخزّن محليًا ومتحسوب مسبقًا.
 */
public class AdhanAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        long now = System.currentTimeMillis();
        List<JSONObject> due = AdhanStore.takeDue(context, now + 3000, now - AdhanScheduler.STALE_MS);
        for (JSONObject o : due) {
            Intent svc = AdhanService.buildPlayIntent(context, o);
            if (svc == null) continue; // ملف الصوت الخاص بالنوع ده مش موجود: نتخطاه
            try {
                ContextCompat.startForegroundService(context, svc);
            } catch (Exception ignored) {
            }
        }
        AdhanScheduler.scheduleNext(context);
    }
}
