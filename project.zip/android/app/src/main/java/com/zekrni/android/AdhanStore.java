package com.zekrni.android;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * مخزن محلي (SharedPreferences) لكل تنبيهات الأذان/التنبيه المسبق المجدولة.
 * الفكرة: بدل ما نسجّل مئات المنبّهات في AlarmManager (وأندرويد بيحدّد 500 منبّه للتطبيق)،
 * بنحفظ الجدول كله هنا، ونسجّل في AlarmManager المنبّه "التالي" بس. أول ما يرن،
 * بنسجّل اللي بعده. وبكده الجدول يفضل شغال حتى لو التطبيق مقفول، وبيتسجّل من جديد بعد إعادة تشغيل الجهاز.
 */
final class AdhanStore {
    private static final String PREFS = "zekrni_adhan_store";
    private static final String KEY = "items";

    private AdhanStore() {}

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static synchronized List<JSONObject> load(Context ctx) {
        List<JSONObject> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(ctx).getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) out.add(arr.getJSONObject(i));
        } catch (Exception ignored) {
        }
        return out;
    }

    private static void save(Context ctx, List<JSONObject> items) {
        Collections.sort(items, new Comparator<JSONObject>() {
            @Override
            public int compare(JSONObject a, JSONObject b) {
                return Long.compare(a.optLong("at", 0), b.optLong("at", 0));
            }
        });
        JSONArray arr = new JSONArray();
        for (JSONObject o : items) arr.put(o);
        prefs(ctx).edit().putString(KEY, arr.toString()).commit();
    }

    /** إضافة/تحديث عناصر (بنفس الـ id بتتكتب فوق القديمة). */
    static synchronized void putAll(Context ctx, JSONArray newItems) {
        Map<Integer, JSONObject> map = new LinkedHashMap<>();
        for (JSONObject o : load(ctx)) map.put(o.optInt("id", 0), o);
        try {
            for (int i = 0; i < newItems.length(); i++) {
                JSONObject o = newItems.getJSONObject(i);
                map.put(o.optInt("id", 0), o);
            }
        } catch (Exception ignored) {
        }
        save(ctx, new ArrayList<>(map.values()));
    }

    static synchronized void removeIds(Context ctx, List<Integer> ids) {
        List<JSONObject> keep = new ArrayList<>();
        for (JSONObject o : load(ctx)) {
            if (!ids.contains(o.optInt("id", 0))) keep.add(o);
        }
        save(ctx, keep);
    }

    static synchronized void removeRange(Context ctx, int minId, int maxId) {
        List<JSONObject> keep = new ArrayList<>();
        for (JSONObject o : load(ctx)) {
            int id = o.optInt("id", 0);
            if (id < minId || id > maxId) keep.add(o);
        }
        save(ctx, keep);
    }

    /**
     * يرجّع العناصر المستحقة الآن (بين staleBefore وdueUntil)، ويمسح من المخزن كل ما هو
     * أقدم من dueUntil (المستحق + القديم جدًا اللي فاته وقته ومينفعش يتشغّل متأخر).
     */
    static synchronized List<JSONObject> takeDue(Context ctx, long dueUntil, long staleBefore) {
        List<JSONObject> due = new ArrayList<>();
        List<JSONObject> keep = new ArrayList<>();
        for (JSONObject o : load(ctx)) {
            long at = o.optLong("at", 0);
            if (at <= dueUntil) {
                if (at > staleBefore) due.add(o);
            } else {
                keep.add(o);
            }
        }
        save(ctx, keep);
        return due;
    }

    /** يمسح كل ما فات وقته بفترة أطول من staleMs (بعد إعادة التشغيل مثلًا). */
    static synchronized void pruneStale(Context ctx, long staleBefore) {
        List<JSONObject> keep = new ArrayList<>();
        for (JSONObject o : load(ctx)) {
            if (o.optLong("at", 0) > staleBefore) keep.add(o);
        }
        save(ctx, keep);
    }
}
