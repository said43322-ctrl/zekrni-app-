package com.zekrni.android;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.ArrayList;
import java.util.List;

/**
 * جسر بين الواجهة (JS) والجدولة الأصلية. الجدول كله بيتخزّن محليًا في AdhanStore،
 * وبيتسجّل في AlarmManager أقرب تنبيه بس (يتكرر تلقائيًا)، فالأذان والتنبيهات المسبقة
 * تفضل شغّالة حتى لو التطبيق مقفول أو الموقع مقفول، وبتترجّع بعد إعادة تشغيل الجهاز.
 */
@CapacitorPlugin(name = "AdhanFullScreen")
public class AdhanFullScreenPlugin extends Plugin {

    /** items: [{id, at(ms), prayerName, isFajr, kind: "adhan"|"pre10"|"pre5"}] */
    @PluginMethod
    public void schedule(PluginCall call) {
        try {
            JSArray items = call.getArray("items");
            if (items != null) AdhanStore.putAll(getContext(), items);
            AdhanScheduler.scheduleNext(getContext());
            call.resolve();
        } catch (Exception e) {
            call.reject("schedule-failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        try {
            JSArray ids = call.getArray("ids");
            List<Integer> list = new ArrayList<>();
            if (ids != null) {
                for (int i = 0; i < ids.length(); i++) list.add(ids.getInt(i));
            }
            if (!list.isEmpty()) AdhanStore.removeIds(getContext(), list);
            AdhanScheduler.scheduleNext(getContext());
            call.resolve();
        } catch (Exception e) {
            call.reject("cancel-failed: " + e.getMessage());
        }
    }

    /** مسح كل التنبيهات في نطاق معيّن من الـ ids (بيتستخدم قبل إعادة الجدولة الكاملة). */
    @PluginMethod
    public void cancelRange(PluginCall call) {
        try {
            int min = call.getInt("min", 0);
            int max = call.getInt("max", Integer.MAX_VALUE);
            AdhanStore.removeRange(getContext(), min, max);
            AdhanScheduler.scheduleNext(getContext());
            call.resolve();
        } catch (Exception e) {
            call.reject("cancel-range-failed: " + e.getMessage());
        }
    }

    /** يطلب استثناء التطبيق من توفير البطارية (مهم عشان بعض الأجهزة بتقتل التطبيق المقفول). */
    @PluginMethod
    public void requestIgnoreBatteryOptimizations(PluginCall call) {
        JSObject res = new JSObject();
        try {
            Context ctx = getContext();
            boolean ignoring = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                ignoring = pm != null && pm.isIgnoringBatteryOptimizations(ctx.getPackageName());
                if (!ignoring) {
                    Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + ctx.getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    ctx.startActivity(i);
                }
            }
            res.put("alreadyIgnoring", ignoring);
            call.resolve(res);
        } catch (Exception e) {
            call.resolve(res);
        }
    }
}
