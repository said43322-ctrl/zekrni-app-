package com.zekrni.android;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.getcapacitor.JSArray;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONObject;

/**
 * Schedules real AlarmManager alarms (not just app-level notifications) so that
 * when a prayer time arrives, Android wakes the device and shows a full-screen
 * "adhan" activity (mosque visual) — the same way an alarm-clock app does —
 * even if the screen is locked or another app is open in the foreground.
 */
@CapacitorPlugin(name = "AdhanFullScreen")
public class AdhanFullScreenPlugin extends Plugin {

    private PendingIntent buildPendingIntent(Context ctx, int id, String prayerName, boolean isFajr) {
        Intent intent = new Intent(ctx, AdhanAlarmReceiver.class);
        intent.putExtra("id", id);
        intent.putExtra("prayerName", prayerName);
        intent.putExtra("isFajr", isFajr);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getBroadcast(ctx, id, intent, flags);
    }

    @PluginMethod
    public void schedule(PluginCall call) {
        JSArray items = call.getArray("items");
        Context ctx = getContext();
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        try {
            if (items != null && am != null) {
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.getJSONObject(i);
                    int id = item.optInt("id", 0);
                    long at = item.optLong("at", 0);
                    String prayerName = item.optString("prayerName", "");
                    boolean isFajr = item.optBoolean("isFajr", false);

                    PendingIntent pi = buildPendingIntent(ctx, id, prayerName, isFajr);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                    } else {
                        am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
                    }
                }
            }
            call.resolve();
        } catch (Exception e) {
            call.reject("schedule-failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        JSArray ids = call.getArray("ids");
        Context ctx = getContext();
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        try {
            if (ids != null && am != null) {
                for (int i = 0; i < ids.length(); i++) {
                    int id = ids.getInt(i);
                    PendingIntent pi = buildPendingIntent(ctx, id, "", false);
                    am.cancel(pi);
                    pi.cancel();
                }
            }
            call.resolve();
        } catch (Exception e) {
            call.reject("cancel-failed: " + e.getMessage());
        }
    }
}
