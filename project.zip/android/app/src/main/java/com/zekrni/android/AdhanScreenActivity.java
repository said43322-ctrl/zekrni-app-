package com.zekrni.android;

import android.app.KeyguardManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationManagerCompat;

/**
 * الشاشة الكاملة اللي بتفتح وقت الأذان. مهم جدًا: صوت الأذان هنا بيتشغّل يدويًا
 * بمشغّل MediaPlayer على "مجرى المنبّه" (STREAM_ALARM) مع طلب Audio Focus صريح،
 * مش بالاعتماد على صوت قناة الإشعار العادية (STREAM_NOTIFICATION). ده الفرق
 * الجوهري: صوت الإشعارات ممكن يتقطع أو يتخفّت لو جالك إشعار من تطبيق تاني في
 * نفس اللحظة، أما "مجرى المنبّه" فله أولوية أعلى في أندرويد (زي منبه الموبايل
 * العادي بالظبط) ومش بيتأثر بإشعارات التطبيقات التانية.
 */
public class AdhanScreenActivity extends AppCompatActivity {
    private MediaPlayer mediaPlayer;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private AudioManager.OnAudioFocusChangeListener focusChangeListener = focusChange -> {};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
            KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            if (km != null) km.requestDismissKeyguard(this, null);
        } else {
            getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            );
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_adhan_screen);

        String prayerName = getIntent().getStringExtra("prayerName");
        final int notificationId = getIntent().getIntExtra("notificationId", 0);
        final boolean isFajr = getIntent().getBooleanExtra("isFajr", false);

        TextView nameView = findViewById(R.id.adhanPrayerName);
        if (nameView != null && prayerName != null && !prayerName.isEmpty()) {
            nameView.setText("أذان " + prayerName);
        }

        playAdhanOnAlarmStream(isFajr);

        Button stopBtn = findViewById(R.id.adhanStopButton);
        if (stopBtn != null) {
            stopBtn.setOnClickListener(v -> {
                NotificationManagerCompat.from(this).cancel(notificationId);
                stopAdhanSound();
                finish();
            });
        }
    }

    private void playAdhanOnAlarmStream(boolean isFajr) {
        try {
            audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            int soundRes = isFajr ? R.raw.adhan_fajr : R.raw.adhan;

            AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();

            boolean focusGranted;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setAudioAttributes(attrs)
                    .setOnAudioFocusChangeListener(focusChangeListener)
                    .build();
                focusGranted = audioManager != null
                    && audioManager.requestAudioFocus(audioFocusRequest) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
            } else {
                focusGranted = audioManager != null
                    && audioManager.requestAudioFocus(
                        focusChangeListener, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                        == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
            }
            // نشغّل الصوت حتى لو رفض النظام الأولوية (نادر) عشان المستخدم يسمع الأذان دايمًا.
            if (!focusGranted) {
                // لسه هنكمل التشغيل، بس بدون ضمان الأولوية القصوى.
            }

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioAttributes(attrs);
            android.content.res.AssetFileDescriptor afd = getResources().openRawResourceFd(soundRes);
            if (afd != null) {
                mediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                afd.close();
            }
            mediaPlayer.setLooping(true);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception e) {
            // لو فشل تشغيل الصوت اليدوي لأي سبب، شاشة الأذان والإشعار الأصلي يفضلوا شغالين برضه.
        }
    }

    private void stopAdhanSound() {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            }
            if (audioManager != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && audioFocusRequest != null) {
                    audioManager.abandonAudioFocusRequest(audioFocusRequest);
                } else {
                    audioManager.abandonAudioFocus(focusChangeListener);
                }
            }
        } catch (Exception e) {
            // تجاهل أي خطأ عند التنظيف — الأهم إن الشاشة تقفل بأمان.
        }
    }

    @Override
    protected void onDestroy() {
        stopAdhanSound();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // Intentionally does nothing: require the explicit stop button so the
        // full-screen adhan reminder can't be dismissed accidentally by mistake.
    }
}
