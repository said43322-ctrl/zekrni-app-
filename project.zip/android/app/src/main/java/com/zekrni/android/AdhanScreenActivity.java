package com.zekrni.android;

import android.app.KeyguardManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationManagerCompat;

public class AdhanScreenActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
            KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            if (km != null) km.requestDismissKeyguard(this, null);
        } else {
            getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            );
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_adhan_screen);

        String prayerName = getIntent().getStringExtra("prayerName");
        final int notificationId = getIntent().getIntExtra("notificationId", 0);

        TextView nameView = findViewById(R.id.adhanPrayerName);
        if (nameView != null && prayerName != null && !prayerName.isEmpty()) {
            nameView.setText("أذان " + prayerName);
        }

        Button stopBtn = findViewById(R.id.adhanStopButton);
        if (stopBtn != null) {
            stopBtn.setOnClickListener(v -> {
                NotificationManagerCompat.from(this).cancel(notificationId);
                finish();
            });
        }
    }

    @Override
    public void onBackPressed() {
        // Intentionally does nothing: require the explicit stop button so the
        // full-screen adhan reminder can't be dismissed accidentally by mistake.
    }
}
