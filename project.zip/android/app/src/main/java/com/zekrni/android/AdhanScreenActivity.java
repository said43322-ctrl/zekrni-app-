package com.zekrni.android;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * شاشة الأذان الكاملة (واجهة فقط). الصوت نفسه بيتشغّل من AdhanService على مجرى المنبّه،
 * فالشاشة بتقفل لوحدها أول ما الأذان + الدعاء يخلصوا، أو بزرار الإيقاف.
 */
public class AdhanScreenActivity extends AppCompatActivity {
    private final BroadcastReceiver doneReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            finish();
        }
    };
    private boolean receiverRegistered = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
            KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            if (km != null) km.requestDismissKeyguard(this, null);
        } else {
            getWindow().addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                            | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                            | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_adhan_screen);
        applyPrayerName(getIntent());

        ContextCompat.registerReceiver(this, doneReceiver,
                new IntentFilter(AdhanService.ACTION_DONE), ContextCompat.RECEIVER_NOT_EXPORTED);
        receiverRegistered = true;

        Button stopBtn = findViewById(R.id.adhanStopButton);
        if (stopBtn != null) {
            stopBtn.setOnClickListener(v -> {
                try {
                    startService(new Intent(this, AdhanService.class).setAction(AdhanService.ACTION_STOP));
                } catch (Exception ignored) {
                }
                finish();
            });
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        applyPrayerName(intent);
    }

    private void applyPrayerName(Intent intent) {
        String prayerName = intent != null ? intent.getStringExtra("prayerName") : null;
        TextView nameView = findViewById(R.id.adhanPrayerName);
        if (nameView != null && prayerName != null && !prayerName.isEmpty()) {
            nameView.setText("أذان " + prayerName);
        }
    }

    @Override
    protected void onDestroy() {
        if (receiverRegistered) {
            try {
                unregisterReceiver(doneReceiver);
            } catch (Exception ignored) {
            }
            receiverRegistered = false;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // بدون سلوك: لازم زرار الإيقاف الصريح عشان الشاشة ما تتقفلش بالغلط.
    }
}
