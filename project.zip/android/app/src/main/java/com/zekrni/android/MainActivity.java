package com.zekrni.android;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NextPrayerWidgetPlugin.class);
        registerPlugin(AdhanFullScreenPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
