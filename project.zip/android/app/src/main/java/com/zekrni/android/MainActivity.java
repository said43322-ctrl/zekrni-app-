package com.zekrni.android;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
}
