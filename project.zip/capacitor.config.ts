import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.zekrni.android',
  appName: 'Zekrni1',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
